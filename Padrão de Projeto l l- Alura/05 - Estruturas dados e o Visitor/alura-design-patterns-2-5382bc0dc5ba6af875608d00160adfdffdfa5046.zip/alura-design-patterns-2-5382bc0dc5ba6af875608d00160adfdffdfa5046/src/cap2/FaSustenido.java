package cap2;

public class FaSustenido implements Nota {

	@Override
	public String simbolo() {
		return "F#";
	}
}