package cap2;

public class Do implements Nota {

	@Override
	public String simbolo() {
		return "C";
	}

}
