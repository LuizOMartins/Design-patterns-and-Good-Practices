package cap7;

public interface Comando {
	public void executa();
}
