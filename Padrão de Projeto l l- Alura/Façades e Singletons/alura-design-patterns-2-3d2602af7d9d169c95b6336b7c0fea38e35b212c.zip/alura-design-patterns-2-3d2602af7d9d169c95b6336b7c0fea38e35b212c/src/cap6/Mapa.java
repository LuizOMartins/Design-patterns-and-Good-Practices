package cap6;

public interface Mapa {
	String devolveMapa(String rua);
}
