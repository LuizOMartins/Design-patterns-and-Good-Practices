package cap2;

public class SolSustenido implements Nota {

	@Override
	public String simbolo() {
		return "G#";
	}
}