package cap2;

public class ReSustenido implements Nota {

	@Override
	public String simbolo() {
		return "D#";
	}
}