package cap2;

public class Mi implements Nota {

	@Override
	public String simbolo() {
		return "E";
	}

}
