package cap8;

class Servico {
	protected Servico() {
	}

	// outros metodos aqui
}