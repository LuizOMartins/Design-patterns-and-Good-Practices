package cap2;

public class Re implements Nota {

	@Override
	public String simbolo() {
		return "D";
	}

}
