package cap2;

public class MiSustenido implements Nota {

	@Override
	public String simbolo() {
		return "E#";
	}
}