package cap2;

public class LaSustenido implements Nota {

	@Override
	public String simbolo() {
		return "C#";
	}
}