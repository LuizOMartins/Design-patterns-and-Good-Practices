package cap2;

public class Si implements Nota {

	@Override
	public String simbolo() {
		return "B";
	}

}
