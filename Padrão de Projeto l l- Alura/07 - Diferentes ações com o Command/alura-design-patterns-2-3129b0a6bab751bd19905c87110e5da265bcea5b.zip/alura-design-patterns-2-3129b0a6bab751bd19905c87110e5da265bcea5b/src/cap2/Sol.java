package cap2;

public class Sol implements Nota {

	@Override
	public String simbolo() {
		return "G";
	}

}
