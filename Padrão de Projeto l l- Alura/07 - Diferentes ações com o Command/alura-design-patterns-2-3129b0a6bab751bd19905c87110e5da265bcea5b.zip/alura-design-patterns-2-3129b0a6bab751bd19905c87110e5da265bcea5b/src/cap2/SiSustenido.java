package cap2;

public class SiSustenido implements Nota {

	@Override
	public String simbolo() {
		return "B#";
	}
}