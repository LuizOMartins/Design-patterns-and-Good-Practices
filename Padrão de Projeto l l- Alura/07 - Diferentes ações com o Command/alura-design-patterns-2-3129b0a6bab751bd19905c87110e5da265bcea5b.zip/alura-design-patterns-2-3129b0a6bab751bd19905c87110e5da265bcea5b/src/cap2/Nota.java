package cap2;

public interface Nota {
	String simbolo();
}
