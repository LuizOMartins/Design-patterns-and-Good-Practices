package cap2;

public class La implements Nota {

	@Override
	public String simbolo() {
		return "A#";
	}

}
