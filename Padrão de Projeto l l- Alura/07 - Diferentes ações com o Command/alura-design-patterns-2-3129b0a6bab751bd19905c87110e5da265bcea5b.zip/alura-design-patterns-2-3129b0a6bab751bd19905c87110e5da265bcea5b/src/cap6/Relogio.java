package cap6;

import java.util.Calendar;

public interface Relogio {
	public Calendar hoje();
}
