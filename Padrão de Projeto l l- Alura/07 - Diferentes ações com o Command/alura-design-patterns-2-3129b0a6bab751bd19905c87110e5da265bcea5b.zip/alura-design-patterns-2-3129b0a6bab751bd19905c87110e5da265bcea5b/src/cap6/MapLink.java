package cap6;

public class MapLink implements Mapa{

	@Override
	public String devolveMapa(String rua) {
		return "mapa do maplink";
	}

}
