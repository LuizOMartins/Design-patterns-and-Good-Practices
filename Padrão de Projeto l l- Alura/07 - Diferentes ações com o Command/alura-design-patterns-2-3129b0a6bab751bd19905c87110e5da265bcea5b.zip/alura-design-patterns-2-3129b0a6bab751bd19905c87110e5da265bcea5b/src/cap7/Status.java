package cap7;

public enum Status {
	NOVO,
	PROCESSANDO,
	PAGO,
	ITEM_SEPARADO,
	ENTREGUE
}
