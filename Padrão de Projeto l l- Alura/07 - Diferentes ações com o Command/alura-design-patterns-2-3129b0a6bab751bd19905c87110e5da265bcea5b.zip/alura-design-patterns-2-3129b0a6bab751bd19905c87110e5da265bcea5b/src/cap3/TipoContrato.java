package cap3;

public enum TipoContrato {
	NOVO, EM_ANDAMENTO, ACERTADO, CONCLUIDO
}
