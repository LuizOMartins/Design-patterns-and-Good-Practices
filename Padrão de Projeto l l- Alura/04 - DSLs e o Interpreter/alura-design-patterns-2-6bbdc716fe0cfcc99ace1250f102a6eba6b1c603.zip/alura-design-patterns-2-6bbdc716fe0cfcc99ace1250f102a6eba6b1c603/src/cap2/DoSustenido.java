package cap2;

public class DoSustenido implements Nota {

	@Override
	public String simbolo() {
		return "C#";
	}
}