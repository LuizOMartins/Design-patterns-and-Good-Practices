package cap4;

public interface Expressao {
	public int avalia();
}
