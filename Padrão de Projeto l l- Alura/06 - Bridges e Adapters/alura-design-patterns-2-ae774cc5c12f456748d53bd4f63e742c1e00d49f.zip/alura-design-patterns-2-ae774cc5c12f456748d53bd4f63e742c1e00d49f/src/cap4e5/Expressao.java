package cap4e5;

public interface Expressao {
	public int avalia();
	void aceita(Visitor impressora);
}
