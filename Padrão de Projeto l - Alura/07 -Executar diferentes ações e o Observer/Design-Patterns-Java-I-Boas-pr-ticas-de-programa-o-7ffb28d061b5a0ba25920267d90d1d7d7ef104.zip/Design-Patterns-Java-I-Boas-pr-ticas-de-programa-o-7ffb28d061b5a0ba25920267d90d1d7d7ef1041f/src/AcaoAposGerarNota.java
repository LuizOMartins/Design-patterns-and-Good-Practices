
public interface AcaoAposGerarNota {
	public void executa(NotaFiscal notaFiscal);
}
