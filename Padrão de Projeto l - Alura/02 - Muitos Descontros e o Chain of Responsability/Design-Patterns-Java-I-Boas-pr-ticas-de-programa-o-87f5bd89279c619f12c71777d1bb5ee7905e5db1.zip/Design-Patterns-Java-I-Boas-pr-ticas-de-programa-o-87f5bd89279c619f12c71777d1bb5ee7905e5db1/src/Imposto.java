
public interface Imposto {
    double calcula(Orcamento orcamento);
}
